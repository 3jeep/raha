"use client";

import { useEffect, useState, useMemo, useCallback } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow } from '@react-google-maps/api';
import { db, auth } from '@/lib/firebase'; 
import { collection, query, where, getDocs, doc, updateDoc, increment } from 'firebase/firestore';
import { onAuthStateChanged } from 'firebase/auth'; 
import { showToast } from "@/lib/utils";
import { useRouter } from 'next/navigation';

// --- معرفك الخاص كمسؤول (Admin) ---
const ADMIN_UID = "sj4uimDJlmQ3XvswnYla4iTHozo1";

// أيقونة الزبون (أفاتار سوداني مبسط بالعمة)
const CUSTOMER_AVATAR = `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(`
<svg xmlns="http://www.w3.org/2000/svg" width="45" height="45" viewBox="0 0 50 50">
  <circle cx="25" cy="25" r="23" fill="white" stroke="#000" stroke-width="1.5"/>
  <path d="M25 8c-6 0-10 3-10 7s4 5 10 5 10-1 10-5-4-7-10-7z" fill="#eee"/> <circle cx="25" cy="20" r="8" fill="#4b2c20"/> <path d="M12 42c0-5 6-9 13-9s13 4 13 9v3H12v-3z" fill="#fff" stroke="#ccc"/> </svg>`)}`;

const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
  const R = 6371; 
  const dLat = (lat2 - lat1) * (Math.PI / 180);
  const dLon = (lon2 - lon1) * (Math.PI / 180);
  const a = 
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * (Math.PI / 180)) * Math.cos(lat2 * (Math.PI / 180)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c; 
};

const professionIcons: { [key: string]: string } = {
  "كهربائي": "⚡", "سباك (مواسيرجي)": "🚰", "فني تكييف وتبريد": "❄️",
  "توصيل طلبات (ركشة/موتر)": "🛵", "ممرض / ممرضة": "🩺", "فني غسالات": "🧺",
  "ميكانيكي": "🔧", "عامل مساعد": "🧹", "نقاش (بويجي)": "🎨",
  "نجار": "🪚", "فني ستالايت (دش)": "📡", "مبلط (سيراميك)": "🧱",
  "حداد": "⚒️", "بناء": "🏗️", "مساعد بناء (طُلبة)": "🧱",
  "طباخ": "👨‍🍳", "حلاق (خدمة منزلية)": "✂️", "غسيل عربات": "🚿", "افتراضي": "👷"
};

export default function MapView({ serviceType }) {
  const router = useRouter();
  const { isLoaded } = useJsApiLoader({
    id: 'google-map-script',
    googleMapsApiKey: "AIzaSyCscTfT9KnGnoGj0dR96n8YbLFk5YdW2p0" 
  });

  const [userLocation, setUserLocation] = useState<{lat: number, lng: number} | null>(null);
  const [handymen, setHandymen] = useState<any[]>([]);
  const [selectedHandyman, setSelectedHandyman] = useState<any>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [currentUser, setCurrentUser] = useState<any>(null); 
  const [hasSearched, setHasSearched] = useState(false); 

  const containerStyle = { width: '100%', height: '100%' };
  const center = useMemo(() => userLocation || { lat: 15.5007, lng: 32.5599 }, [userLocation]);

  const mapOptions = useMemo(() => ({
    gestureHandling: "greedy",
    disableDefaultUI: false,
    zoomControl: false,
    mapTypeControl: false,
    streetViewControl: false,
    fullscreenControl: false,
  }), []);

  const createCustomMarkerUrl = (handyman: any) => {
    const iconText = professionIcons[handyman.profession] || professionIcons["افتراضي"];
    const strokeColor = handyman.isVerified ? '#2563eb' : 'black';
    const svg = `<svg xmlns="http://www.w3.org/2000/svg" width="40" height="40" viewBox="0 0 40 40"><defs><clipPath id="circleView"><circle cx="20" cy="20" r="18" /></clipPath></defs><circle cx="20" cy="20" r="20" fill="${strokeColor}" /><circle cx="20" cy="20" r="18" fill="white" />${handyman.photoURL ? `<image href="${handyman.photoURL}" x="2" y="2" width="36" height="36" clip-path="url(#circleView)" />` : `<text x="50%" y="55%" dominant-baseline="middle" text-anchor="middle" font-size="20" font-family="Arial">${iconText}</text>`}</svg>`;
    return `data:image/svg+xml;charset=UTF-8,${encodeURIComponent(svg)}`;
  };

  const autoFitBounds = useCallback(() => {
    if (map && userLocation && handymen.length > 0) {
      const bounds = new google.maps.LatLngBounds();
      bounds.extend(userLocation);
      handymen.slice(0, 3).forEach(h => bounds.extend({ lat: h.lat, lng: h.lng }));
      map.fitBounds(bounds);
      const listener = google.maps.event.addListener(map, "idle", () => {
        if (map.getZoom()! > 15) map.setZoom(15); 
        google.maps.event.removeListener(listener);
      });
    }
  }, [map, userLocation, handymen]);

  useEffect(() => {
    const unsubscribeAuth = onAuthStateChanged(auth, (user) => setCurrentUser(user));
    navigator.geolocation.getCurrentPosition(
      (pos) => setUserLocation({ lat: pos.coords.latitude, lng: pos.coords.longitude }),
      () => showToast("يرجى تفعيل الموقع لنريك الحرفيين حولك", "error")
    );
    return () => unsubscribeAuth();
  }, []);

  useEffect(() => {
    const fetchRealData = async () => {
      try {
        const q = query(collection(db, "handymen"), where("profession", "==", serviceType));
        const snap = await getDocs(q);
        const data = snap.docs.map(doc => {
          const hData = doc.data();
          let distance = 0;
          if (userLocation && hData.lat && hData.lng) {
            distance = calculateDistance(userLocation.lat, userLocation.lng, hData.lat, hData.lng);
          }
          return { id: doc.id, ...hData, distance };
        })
        .filter(h => h.distance <= 20 && (h.isActive !== false));
        
        setHandymen(data.sort((a, b) => a.distance - b.distance));
        setHasSearched(true); 
      } catch (error) { 
        console.error("Error:", error); 
        setHasSearched(true);
      }
    };
    if (serviceType && userLocation) fetchRealData();
  }, [serviceType, userLocation]);

  useEffect(() => {
    if (hasSearched && handymen.length > 0) {
      autoFitBounds();
    }
  }, [hasSearched, handymen, autoFitBounds]);

  const handleAction = async (handyman, type) => {
    try {
      const handymanRef = doc(db, "handymen", handyman.id);
      await updateDoc(handymanRef, { total_calls: increment(1) });
      const statsRef = doc(db, "admin_stats", "tracking");
      await updateDoc(statsRef, { [type === 'call' ? 'total_calls' : 'total_whatsapp']: increment(1) });
    } catch (e) { console.error(e); }
    window.open(type === 'call' ? `tel:${handyman.phone}` : `https://wa.me/${handyman.phone}`);
  };

  const handleRating = async (handymanId, newRate) => {
    try {
      const handymanRef = doc(db, "handymen", handymanId);
      await updateDoc(handymanRef, { rating: newRate });
      showToast("شكراً لتقييمك! ❤️", "success");
      setHandymen(prev => prev.map(h => h.id === handymanId ? {...h, rating: newRate} : h));
      if (selectedHandyman?.id === handymanId) setSelectedHandyman({...selectedHandyman, rating: newRate});
    } catch (e) { showToast("عذراً، لم يكتمل التقييم", "error"); }
  };

  const handleAdminUpdate = async (handymanId, field, value) => {
    if (currentUser?.uid !== ADMIN_UID) return;
    try {
      const handymanRef = doc(db, "handymen", handymanId);
      await updateDoc(handymanRef, { [field]: value });
      showToast("تم التحديث بنجاح ✅", "success");
      setHandymen(prev => prev.map(h => h.id === handymanId ? {...h, [field]: value} : h));
      if (selectedHandyman?.id === handymanId) setSelectedHandyman({...selectedHandyman, [field]: value});
    } catch (e) { showToast("فشل في التحديث الإداري", "error"); }
  };

  if (!isLoaded) return <div className="h-full w-full flex items-center justify-center font-black text-gray-400">جاري تحميل الخريطة...</div>;
  
  if (!userLocation) return <div className="h-full w-full flex flex-col items-center justify-center font-black px-6 text-center animate-pulse text-blue-700" dir="rtl">
    <span className="text-4xl mb-3">📍</span>
    انتظر لحظة.. جاري تحديد موقعك الحالي لخدمتك بأفضل صورة
  </div>;

  if (userLocation && !hasSearched) return <div className="h-full w-full flex flex-col items-center justify-center font-black px-6 text-center animate-pulse text-green-700" dir="rtl">
    <span className="text-4xl mb-3">⚙️</span>
    جاري معالجة البيانات والبحث عن أقرب {serviceType} حولك...
  </div>;

  if (hasSearched && handymen.length === 0) {
    return (
      <div className="h-full w-full flex flex-col items-center justify-center bg-gray-50 p-6 text-center" dir="rtl">
        <div className="bg-white p-8 rounded-[32px] shadow-2xl border-2 border-black max-w-sm w-full">
           <span className="text-6xl mb-4 block">😔</span>
           <h2 className="text-[20px] font-black text-black mb-2">آسفين جداً!</h2>
           <p className="text-[14px] text-gray-500 font-bold mb-6 leading-relaxed">
             لا يوجد <span className="text-black">{serviceType}</span> مسجل لدينا حالياً (أو متاح) في منطقتك. 
             <br/> عد مرة أخرى قريباً.
           </p>
           <button onClick={() => window.location.reload()} className="w-full bg-black text-white py-4 rounded-2xl font-black text-[16px] active:scale-95 transition-all shadow-lg">تحديث البحث</button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative h-full w-full">
      {currentUser?.uid === ADMIN_UID && (
        <div className="absolute top-20 right-4 z-[100] bg-black/80 text-white p-3 rounded-2xl text-[10px] font-mono border border-yellow-500 backdrop-blur-md" dir="rtl">
          <p className="text-yellow-500 font-black mb-1">🛠 وضع المطور (إبراهيم)</p>
          <p>استهلاك اليوم التقريبي: {handymen.length + 1} طلبات</p>
        </div>
      )}

      <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={13} options={mapOptions} onLoad={(m) => setMap(m)}>
        {userLocation && <Marker position={userLocation} icon={CUSTOMER_AVATAR} />}
        {handymen.map(h => (
          <Marker key={h.id} position={{ lat: h.lat, lng: h.lng }} icon={createCustomMarkerUrl(h)} onClick={() => setSelectedHandyman(h)} />
        ))}

        {selectedHandyman && (
          <InfoWindow position={{ lat: selectedHandyman.lat, lng: selectedHandyman.lng }} onCloseClick={() => setSelectedHandyman(null)}>
            <div className="p-3 text-right w-56 bg-white" dir="rtl">
              <div className="flex flex-wrap gap-1.5 mb-2">
                <span className="text-[10px] font-black text-green-700 bg-green-50 px-2 py-0.5 rounded-full border border-green-100">● متاح الآن</span>
                {selectedHandyman.isVerified === true && (
                  <span className="text-[11px] font-black text-blue-700 bg-blue-50 px-2 py-1 rounded-full border border-blue-100">✅ موثوق</span>
                )}
                {(selectedHandyman.total_calls >= 50) && (
                  <span className="text-[11px] font-black text-orange-700 bg-orange-50 px-2 py-1 rounded-full animate-pulse border border-orange-100">🔥 الأكثر طلباً</span>
                )}
              </div>

              <h3 className="font-black text-[16px] text-gray-900 leading-tight mb-0.5">{selectedHandyman.name}</h3>
              
              {/* عرض وصف الموقع (الحي/المنطقة) المضاف يدوياً */}
              {selectedHandyman.locationName && (
                <p className="text-[10px] font-black text-blue-600 mb-2 flex items-center gap-1">
                  📍 {selectedHandyman.locationName}
                </p>
              )}

              {selectedHandyman.bio && <p className="text-[11px] text-gray-600 mb-2 leading-relaxed border-t border-gray-50 pt-1">{selectedHandyman.bio}</p>}
              
              <div className="flex items-center justify-between mt-2 mb-3 bg-gray-50 p-2 rounded-xl">
                 <div className="flex flex-col">
                    <span className="text-[10px] text-gray-400 font-bold">التقييم الحالي</span>
                    <span className="text-yellow-500 font-black text-[14px]">⭐ {selectedHandyman.rating?.toFixed(1) || "5.0"}</span>
                 </div>
                 <span className="text-[18px] font-black text-blue-900">{selectedHandyman.distance.toFixed(2)} كم</span>
              </div>

              <div className="mb-3 text-center">
                <p className="text-[10px] font-bold text-gray-400 mb-1">قيم جودة الخدمة:</p>
                <div className="flex justify-center gap-1">
                  {[1, 2, 3, 4, 5].map((star) => (
                    <button key={star} onClick={() => handleRating(selectedHandyman.id, star)} className="text-[18px] hover:scale-125 transition-transform">⭐</button>
                  ))}
                </div>
              </div>

              {currentUser?.uid === ADMIN_UID && (
                <div className="mt-2 pt-2 border-t-2 border-dashed border-yellow-200 bg-yellow-50/50 p-2 rounded-xl mb-3 text-center">
                  <p className="text-[9px] font-black text-yellow-800">تحكم إبراهيم (الطلبات: {selectedHandyman.total_calls || 0})</p>
                  <button onClick={() => handleAdminUpdate(selectedHandyman.id, 'isVerified', !selectedHandyman.isVerified)} className="text-[9px] font-black py-1 px-3 mt-1 bg-blue-600 text-white rounded-lg">
                    {selectedHandyman.isVerified ? "إلغاء التوثيق" : "توثيق الآن"}
                  </button>
                </div>
              )}

              <div className="flex gap-2">
                <button onClick={() => handleAction(selectedHandyman, 'call')} className="flex-1 bg-black text-white py-2.5 rounded-xl text-[11px] font-black active:scale-95 transition-all shadow-lg">اتصال</button>
                <button onClick={() => handleAction(selectedHandyman, 'wa')} className="flex-1 bg-green-600 text-white py-2.5 rounded-xl text-[11px] font-black active:scale-95 transition-all shadow-lg">واتساب</button>
              </div>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>
    </div>
  );
}
