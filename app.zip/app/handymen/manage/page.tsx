"use client";

import { useState, useEffect } from 'react';
import { db, auth } from '@/lib/firebase';
import { 
  collection, doc, getDocs, query, where, 
  deleteDoc, updateDoc, serverTimestamp, addDoc 
} from 'firebase/firestore';
import { onAuthStateChanged, signOut } from 'firebase/auth';
import { useRouter } from 'next/navigation';
import { showToast } from "@/lib/utils";
import Link from 'next/link';

const professionsList = [
  "كهربائي", "سباك (مواسيرجي)", "فني تكييف وتبريد", "توصيل طلبات (ركشة/موتر)",
  "ممرض / ممرضة", "فني غسالات", "ميكانيكي", "عامل مساعد", "نقاش (بويجي)",
  "نجار", "فني ستالايت (دش)", "مبلط (سيراميك)", "حداد", "بناء",
  "مساعد بناء (طُلبة)", "طباخ", "حلاق (خدمة منزلية)", "غسيل عربات"
];

export default function ManageHandyman() {
  const [user, setUser] = useState<any>(null);
  const [myServices, setMyServices] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [step, setStep] = useState(1); 
  const router = useRouter();

  const [newService, setNewService] = useState({
    profession: professionsList[0],
    phone: "",
    bio: "", 
    locationName: "",
    lat: null as number | null,
    lng: null as number | null
  });

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, (currentUser) => {
      if (currentUser) {
        setUser(currentUser);
        fetchMyServices(currentUser.uid);
      } else {
        if (typeof window !== 'undefined') {
          sessionStorage.setItem('returnUrl', window.location.pathname);
        }
        router.push('/login');
      }
    });
    return () => unsubscribe();
  }, [router]);

  const fetchMyServices = async (uid: string) => {
    try {
      const q = query(collection(db, "handymen"), where("uid", "==", uid));
      const snap = await getDocs(q);
      setMyServices(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    } catch (e) { showToast("خطأ في جلب البيانات", "error"); }
    finally { setLoading(false); }
  };

  const toggleAvailability = async (serviceId: string, currentStatus: boolean) => {
    try {
      const serviceRef = doc(db, "handymen", serviceId);
      await updateDoc(serviceRef, { isActive: !currentStatus });
      setMyServices(prev => prev.map(s => s.id === serviceId ? { ...s, isActive: !currentStatus } : s));
      showToast(!currentStatus ? "أنت متاح الآن للزبائن ✅" : "تم تعيين الحالة: مشغول 💤", "success");
    } catch (e) { showToast("عذراً، فشل تحديث الحالة", "error"); }
  };

  const updateCurrentLocation = () => {
    if (!navigator.geolocation) return showToast("متصفحك لا يدعم الـ GPS", "error");
    setLoading(true);
    navigator.geolocation.getCurrentPosition(
      (pos) => {
        setNewService(prev => ({ ...prev, lat: pos.coords.latitude, lng: pos.coords.longitude }));
        showToast("تم تحديد موقعك بنجاح 📍", "success");
        setLoading(false);
      },
      (error) => {
        showToast("يرجى تفعيل الـ GPS والسماح بالوصول للموقع", "error");
        setLoading(false);
      },
      { enableHighAccuracy: true }
    );
  };

  const handleEditInit = (service: any) => {
    setEditingId(service.id);
    setNewService({
      profession: service.profession,
      phone: service.phone,
      bio: service.bio || "",
      locationName: service.locationName || "",
      lat: service.lat,
      lng: service.lng
    });
    setShowAddForm(true);
    setStep(1);
  };

  const handleSaveService = async () => {
    if (!newService.lat || !newService.lng) return showToast("يجب تحديث موقعك أولاً", "error");
    if (!newService.locationName) return showToast("يرجى كتابة اسم المنطقة أو الحي", "error");
    
    try {
      setLoading(true);
      const serviceData = {
        uid: user.uid,
        name: user.displayName || user.fullName || "حرفي راحة",
        profession: newService.profession,
        phone: newService.phone,
        bio: newService.bio,
        locationName: newService.locationName,
        lat: newService.lat,
        lng: newService.lng,
        updatedAt: serverTimestamp()
      };

      if (editingId) {
        await updateDoc(doc(db, "handymen", editingId), serviceData);
        showToast("تم تحديث البيانات بنجاح ✨", "success");
      } else {
        await addDoc(collection(db, "handymen"), {
          ...serviceData,
          isVerified: false,
          isActive: true,
          rating: 5.0,
          total_calls: 0,
          reviewsCount: 0,
          createdAt: serverTimestamp()
        });
        showToast("تمت إضافة الحرفة بنجاح ✨", "success");
      }
      
      resetForm();
      fetchMyServices(user.uid);
    } catch (e) { showToast("فشل الحفظ", "error"); }
    finally { setLoading(false); }
  };

  const resetForm = () => {
    setShowAddForm(false);
    setEditingId(null);
    setStep(1);
    setNewService({ profession: professionsList[0], phone: "", bio: "", locationName: "", lat: null, lng: null });
  };

  const handleLogout = async () => {
    await signOut(auth);
    router.push('/login');
  };

  if (loading && !user) return <div className="p-10 text-center font-black">جاري التحميل...</div>;

  return (
    <div className="min-h-screen bg-gray-50 p-4 font-sans pb-20" dir="rtl">
      <div className="max-w-md mx-auto">
        
        {/* هيدر مطور مع زر رجوع */}
        <header className="bg-white p-4 rounded-3xl shadow-sm border border-gray-100 mb-6">
          <div className="flex justify-between items-center mb-4">
            <Link href="/" className="text-[10px] font-black text-gray-500 bg-gray-100 px-4 py-2 rounded-xl flex items-center gap-1">
               <span>➔</span> الرجوع للرئيسية
            </Link>
            <button onClick={handleLogout} className="text-[10px] font-black text-red-500 bg-red-50 px-3 py-2 rounded-xl">تسجيل خروج</button>
          </div>
          
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 bg-black rounded-2xl flex items-center justify-center text-white font-bold text-xl">
              {user?.displayName?.charAt(0) || "U"}
            </div>
            <div>
              <h2 className="text-sm font-black text-gray-900">{user?.displayName || "مستخدم راحة"}</h2>
              <p className="text-[10px] text-gray-400 font-bold">لوحة تحكم الحرفيين</p>
            </div>
          </div>
        </header>

        {!showAddForm && (
          <button 
            onClick={() => setShowAddForm(true)}
            className="w-full mb-6 bg-black text-white p-5 rounded-3xl font-black text-sm shadow-xl flex items-center justify-center gap-2 active:scale-95 transition-transform"
          >
            <span className="text-xl">+</span> إضافة حرفة جديدة
          </button>
        )}

        {/* قائمة الحرف المسجلة */}
        <section className="space-y-4 mb-10">
          <div className="flex justify-between items-center px-2">
            <h2 className="text-[10px] font-black text-gray-400 uppercase tracking-widest">حرفي المسجلة ({myServices.length})</h2>
          </div>
          
          {myServices.length === 0 && !showAddForm && (
            <div className="text-center py-10 bg-white rounded-3xl border-2 border-dashed border-gray-200">
               <p className="text-gray-400 font-bold text-xs">لا توجد حرف مسجلة باسمك حالياً</p>
            </div>
          )}

          {myServices.map((s) => (
            <div key={s.id} className="bg-white p-5 rounded-[2rem] shadow-sm border border-gray-100 flex flex-col gap-4">
              <div className="flex justify-between items-start">
                <div>
                  <div className="flex items-center gap-2 mb-1">
                    <h3 className="font-black text-[16px] text-gray-900">{s.profession}</h3>
                    {s.isVerified && <span className="bg-blue-600 text-white text-[8px] px-2 py-0.5 rounded-full font-black flex items-center gap-0.5 shadow-sm">✔ موثوق</span>}
                  </div>
                  <p className="text-[11px] text-gray-500 font-bold mb-2">📍 {s.locationName || "موقع غير محدد"}</p>
                  <div className="flex items-center gap-3">
                    <span className="text-yellow-500 font-black text-[12px] bg-yellow-50 px-2 py-0.5 rounded-lg">⭐ {s.rating?.toFixed(1) || "5.0"}</span>
                    <span className="text-gray-400 font-black text-[10px]">📞 {s.total_calls || 0} طلب</span>
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <button onClick={() => handleEditInit(s)} className="text-blue-600 bg-blue-50 p-2 rounded-xl text-[10px] font-black">تعديل</button>
                  <button onClick={() => { if(confirm("هل أنت متأكد من حذف هذه الحرفة نهائياً؟")) deleteDoc(doc(db, "handymen", s.id)).then(()=>fetchMyServices(user.uid)) }} className="text-red-500 bg-red-50 p-2 rounded-xl text-[10px] font-black">حذف</button>
                </div>
              </div>
              
              <button 
                onClick={() => toggleAvailability(s.id, s.isActive ?? true)}
                className={`w-full py-4 rounded-2xl text-[12px] font-black transition-all flex items-center justify-center gap-2 border-2 ${
                  (s.isActive ?? true) 
                  ? 'bg-green-500 text-white border-green-500 shadow-lg shadow-green-100' 
                  : 'bg-white text-gray-400 border-gray-200'
                }`}
              >
                {(s.isActive ?? true) ? '● أنت متاح الآن للزبائن' : '○ مشغول (مخفي من الخريطة)'}
              </button>
            </div>
          ))}
        </section>

        {/* نموذج الإضافة/التعديل (خطوات) */}
        {showAddForm && (
          <div className="bg-white p-6 rounded-3xl shadow-2xl border-2 border-black mb-10">
            <div className="flex gap-2 mb-6">
              {[1, 2, 3].map(i => (
                <div key={i} className={`h-1.5 flex-1 rounded-full ${step >= i ? 'bg-black' : 'bg-gray-100'}`} />
              ))}
            </div>

            {step === 1 && (
              <div className="space-y-4 animate-in slide-in-from-left">
                <h3 className="font-black text-lg">1. نوع الحرفة</h3>
                <p className="text-[10px] text-gray-400 font-bold">اختر الحرفة التي تتقنها ليجدك الزبائن</p>
                <select className="w-full p-4 bg-gray-50 rounded-2xl font-bold text-sm outline-none border-2 border-transparent focus:border-black appearance-none" value={newService.profession} onChange={(e) => setNewService({...newService, profession: e.target.value})}>
                  {professionsList.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                <button onClick={() => setStep(2)} className="w-full bg-black text-white p-4 rounded-2xl font-black text-xs shadow-lg">التالي</button>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-4 animate-in slide-in-from-left">
                <h3 className="font-black text-lg">2. المنطقة والموقع</h3>
                <p className="text-[10px] text-gray-400 font-bold">اكتب اسم الحي وحدث إحداثياتك ليراك الأقرب إليك</p>
                <input 
                  type="text" 
                  placeholder="مثلاً: الخرطوم، المعمورة - مربع 84" 
                  className="w-full p-4 bg-gray-50 rounded-2xl font-bold text-sm outline-none border-2 border-transparent focus:border-black" 
                  value={newService.locationName} 
                  onChange={(e) => setNewService({...newService, locationName: e.target.value})} 
                />
                <button onClick={updateCurrentLocation} className={`w-full p-4 rounded-2xl font-black text-xs flex items-center justify-center gap-2 transition-all ${newService.lat ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-blue-600 text-white shadow-lg'}`}>
                  {newService.lat ? "✅ تم حفظ إحداثيات موقعك" : "📍 تحديث موقعي على الخريطة"}
                </button>
                <div className="flex gap-2 pt-2">
                  <button onClick={() => setStep(1)} className="flex-1 p-4 bg-gray-100 rounded-2xl font-black text-xs text-gray-500">سابق</button>
                  <button disabled={!newService.lat || !newService.locationName} onClick={() => setStep(3)} className="flex-[2] bg-black text-white p-4 rounded-2xl font-black text-xs disabled:opacity-30">التالي</button>
                </div>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-4 animate-in slide-in-from-left">
                <h3 className="font-black text-lg">3. التواصل والنبذة</h3>
                <input type="tel" placeholder="رقم الهاتف (واتساب)" className="w-full p-4 bg-gray-50 rounded-2xl font-bold text-sm outline-none border-2 border-transparent focus:border-black" value={newService.phone} onChange={(e) => setNewService({...newService, phone: e.target.value})} />
                <textarea placeholder="نبذة مختصرة عن خبرتك (اختياري)" className="w-full p-4 bg-gray-50 rounded-2xl font-bold text-sm outline-none border-2 border-transparent focus:border-black h-24" value={newService.bio} onChange={(e) => setNewService({...newService, bio: e.target.value})} />
                <div className="flex gap-2">
                  <button onClick={() => setStep(2)} className="flex-1 p-4 bg-gray-100 rounded-2xl font-black text-xs text-gray-500">سابق</button>
                  <button onClick={handleSaveService} className="flex-[2] bg-green-600 text-white p-4 rounded-2xl font-black text-xs shadow-lg shadow-green-100">
                    {editingId ? 'حفظ التعديلات' : 'نشر الحرفة الآن'}
                  </button>
                </div>
              </div>
            )}
            <button onClick={resetForm} className="w-full mt-6 text-[10px] font-black text-gray-300 uppercase tracking-widest hover:text-red-400">إلغاء العملية</button>
          </div>
        )}

        {/* قسم الملاحظات والإرشادات (أسفل الصفحة) */}
        <footer className="mt-10 p-6 bg-blue-50/50 rounded-[2.5rem] border border-blue-100">
           <h4 className="text-[12px] font-black text-blue-900 mb-4 flex items-center gap-2">
             💡 معلومات تهمك يا حرفي:
           </h4>
           <ul className="space-y-4">
             <li className="flex gap-3">
               <span className="text-lg">✅</span>
               <div>
                 <p className="text-[11px] font-black text-gray-800 mb-0.5">كيف تحصل على علامة "موثوق"؟</p>
                 <p className="text-[10px] text-gray-500 leading-relaxed">علامة التوثيق تمنحها الإدارة يدوياً بعد التأكد من جودة خدمتك وعدد طلباتك الناجحة. التزم بالمواعيد وستحصل عليها قريباً.</p>
               </div>
             </li>
             <li className="flex gap-3">
               <span className="text-lg">⭐</span>
               <div>
                 <p className="text-[11px] font-black text-gray-800 mb-0.5">نظام التقييم</p>
                 <p className="text-[10px] text-gray-500 leading-relaxed">تقييمك يعتمد مباشرة على رأي الزبائن. التقييم العالي (أعلى من 4.5) يجعلك تظهر في مقدمة البحث دائماً.</p>
               </div>
             </li>
             <li className="flex gap-3">
               <span className="text-lg">📍</span>
               <div>
                 <p className="text-[11px] font-black text-gray-800 mb-0.5">تحديث الموقع</p>
                 <p className="text-[10px] text-gray-500 leading-relaxed">إذا انتقلت لحي آخر أو غيرت مكان عملك، تأكد من "تعديل" الحرفة وتحديث إحداثيات الموقع ليراك الزبائن في منطقتك الجديدة.</p>
               </div>
             </li>
           </ul>
           <div className="mt-6 pt-4 border-t border-blue-100 text-center">
              <p className="text-[9px] font-bold text-blue-400 italic">مشروع "راحة" - لخدمة المجتمع السوداني</p>
           </div>
        </footer>

      </div>
    </div>
  );
}
